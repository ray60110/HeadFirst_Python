from distutils.core import setup

setup(
    name= 'nester',
    version='1.3.0',
    py_modules= ['nester'],
    author='ray60110',
    author_email='ray60110@gmail.com',
    url='...',
    )
